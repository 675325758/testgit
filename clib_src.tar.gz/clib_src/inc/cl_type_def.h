/**************************************************************************
**************************************************************************/


#ifndef CL_TYPE_DEF_H
#define CL_TYPE_DEF_H


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/* Include files. */


/* Macro constant definitions. */


/* External function declarations. */


/* Macro API definitions. */


/* Global variable declarations. */
enum{
	APP_ID_NONE = 0,
	APP_ID_HTL,
	APP_ID_MAX,
};



#ifdef __cplusplus
} /* extern "C" */
#endif /* __cplusplus */

#endif /* CL_LANUSERS_H */





